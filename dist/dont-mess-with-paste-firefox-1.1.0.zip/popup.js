(function () {
  const toggle = document.getElementById("toggle");
  const forceToggle = document.getElementById("forceToggle");
  const dot = document.getElementById("statusDot");
  const text = document.getElementById("statusText");
  let tabId = null;
  let initialized = false;

  function updateUI(enabled, forceMode) {
    toggle.checked = enabled;
    dot.classList.toggle("off", !enabled);
    text.textContent = enabled ? "Active on this site" : "Disabled on this site";
    toggle.disabled = false;
    forceToggle.checked = forceMode;
    forceToggle.disabled = !enabled;
  }

  function setUnavailable(message) {
    toggle.checked = false;
    toggle.disabled = true;
    forceToggle.checked = false;
    forceToggle.disabled = true;
    dot.classList.add("off");
    text.textContent = message;
  }

  function reloadActiveTab() {
    if (tabId == null) return;
    chrome.tabs.reload(tabId);
  }

  function parseHostname(tab) {
    if (!tab) return "";
    const candidates = [tab.url, tab.pendingUrl];
    for (const candidate of candidates) {
      if (!candidate) continue;
      try {
        return new URL(candidate).hostname;
      } catch (_) {}
    }
    return "";
  }

  function initForHostname(hostname) {
    if (initialized) return;
    initialized = true;

    const disabledKey = "disabled_" + hostname;
    const forceKey = "force_" + hostname;

    chrome.storage.local.get([disabledKey, forceKey], function (result) {
      if (chrome.runtime.lastError) {
        setUnavailable("Storage not available on this page");
        return;
      }

      const enabled = !result[disabledKey];
      const forceMode = !!result[forceKey];
      updateUI(enabled, forceMode);
    });

    toggle.addEventListener("change", function () {
      const enabled = toggle.checked;
      updateUI(enabled, forceToggle.checked);

      if (enabled) {
        chrome.storage.local.remove(disabledKey);
      } else {
        chrome.storage.local.set({ [disabledKey]: true });
      }

      // Reload the tab so the content script picks up the new state
      reloadActiveTab();
    });

    forceToggle.addEventListener("change", function () {
      if (forceToggle.disabled) return;

      const forceMode = forceToggle.checked;
      if (forceMode) {
        chrome.storage.local.set({ [forceKey]: true });
      } else {
        chrome.storage.local.remove(forceKey);
      }

      // Reload the tab so the content script picks up the new state
      reloadActiveTab();
    });
  }

  // Get current tab hostname, with fallback via content script for Firefox/permission-limited tabs.
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    if (chrome.runtime.lastError || !tabs[0]) {
      setUnavailable("Unable to access this tab");
      return;
    }

    tabId = tabs[0].id;
    const directHostname = parseHostname(tabs[0]);
    if (directHostname) {
      initForHostname(directHostname);
      return;
    }

    if (tabId == null) {
      setUnavailable("Unavailable on this page");
      return;
    }

    chrome.tabs.sendMessage(tabId, { type: "getHostname" }, function (response) {
      if (chrome.runtime.lastError || !response || !response.hostname) {
        setUnavailable("Unavailable on browser/internal pages");
        return;
      }

      initForHostname(response.hostname);
    });
  });
})();
