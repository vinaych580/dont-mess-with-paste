(function () {
  "use strict";

  chrome.runtime.onMessage.addListener(function (message, _sender, sendResponse) {
    if (message && message.type === "getHostname") {
      sendResponse({ hostname: location.hostname });
    }
  });

  // Check if the extension is disabled for this site before doing anything
  const hostname = location.hostname;
  chrome.runtime.sendMessage({ type: "checkEnabled", hostname: hostname }, function (response) {
    if (chrome.runtime.lastError || (response && !response.enabled)) return;
    activate(!!(response && response.forceMode));
  });

  function activate(forceMode) {
    const BLOCKED_EVENTS = ["copy", "paste", "cut", "selectstart", "contextmenu"];
    const FORCED_EVENTS = ["keydown", "beforeinput"];

    // 1. Inject CSS to re-enable text selection
    const style = document.createElement("style");
    style.textContent = "* { user-select: auto !important; -webkit-user-select: auto !important; }";
    (document.head || document.documentElement).appendChild(style);

    // 2. Remove inline event handler attributes from all elements
    function cleanElement(el) {
      if (!el) return;
      for (const evt of BLOCKED_EVENTS) {
        const prop = "on" + evt;
        if (typeof el.removeAttribute === "function") {
          el.removeAttribute(prop);
        }
        try {
          el[prop] = null;
        } catch (_) {}
      }
    }

    function cleanAllElements() {
      cleanElement(document);
      cleanElement(window);
      for (const el of document.querySelectorAll("*")) {
        cleanElement(el);
      }
    }

    // Run cleanup once DOM is ready, and again after full load
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", cleanAllElements);
    } else {
      cleanAllElements();
    }
    window.addEventListener("load", cleanAllElements);

    // Watch for dynamically added elements
    if (document.documentElement) {
      const observer = new MutationObserver(function (mutations) {
        for (const mutation of mutations) {
          for (const node of mutation.addedNodes) {
            if (node.nodeType === Node.ELEMENT_NODE) {
              cleanElement(node);
              for (const child of node.querySelectorAll("*")) {
                cleanElement(child);
              }
            }
          }
        }
      });
      observer.observe(document.documentElement, { childList: true, subtree: true });
    }

    // 3. In force mode, swallow blocking listeners before page scripts can hijack them.
    if (forceMode) {
      const allGuardedEvents = BLOCKED_EVENTS.concat(FORCED_EVENTS);
      const shouldGuard = function (event) {
        if (BLOCKED_EVENTS.includes(event.type)) return true;

        if (event.type === "keydown") {
          if (!(event.ctrlKey || event.metaKey)) return false;
          const key = typeof event.key === "string" ? event.key.toLowerCase() : "";
          return key === "c" || key === "x" || key === "v";
        }

        if (event.type === "beforeinput") {
          const inputType = typeof event.inputType === "string" ? event.inputType : "";
          return inputType === "insertFromPaste" || inputType === "deleteByCut";
        }

        return false;
      };

      const guard = function (event) {
        if (!shouldGuard(event)) return;
        event.stopImmediatePropagation();
        event.stopPropagation();
      };

      for (const evt of allGuardedEvents) {
        window.addEventListener(evt, guard, true);
        document.addEventListener(evt, guard, true);
      }
    }

    // 4. Inject a page-level script to intercept addEventListener
    //    Content scripts run in an isolated world, so we need to inject
    //    into the page's JS context to intercept calls made by page scripts.
    const script = document.createElement("script");
    script.textContent = `(function() {
      var blockedEvents = ${JSON.stringify(BLOCKED_EVENTS)};
      var forceMode = ${forceMode ? "true" : "false"};
      var originalAddEventListener = EventTarget.prototype.addEventListener;
      var originalRemoveEventListener = EventTarget.prototype.removeEventListener;
      var wrappedFunctionListeners = new WeakMap();
      var wrappedObjectListeners = new WeakMap();

      function shouldWrapType(type) {
        if (blockedEvents.includes(type)) return true;
        if (!forceMode) return false;
        return type === "keydown" || type === "beforeinput";
      }

      function shouldIgnorePreventDefault(event) {
        if (blockedEvents.includes(event.type)) return true;
        if (!forceMode) return false;

        if (event.type === "keydown") {
          if (!(event.ctrlKey || event.metaKey)) return false;
          var key = typeof event.key === "string" ? event.key.toLowerCase() : "";
          return key === "c" || key === "x" || key === "v";
        }

        if (event.type === "beforeinput") {
          var inputType = typeof event.inputType === "string" ? event.inputType : "";
          return inputType === "insertFromPaste" || inputType === "deleteByCut";
        }

        return false;
      }

      function getWrappedFunction(type, listener) {
        var byType = wrappedFunctionListeners.get(listener);
        if (!byType) {
          byType = new Map();
          wrappedFunctionListeners.set(listener, byType);
        }

        var wrapped = byType.get(type);
        if (wrapped) return wrapped;

        wrapped = function(event) {
          var origPreventDefault = event.preventDefault;
          if (shouldIgnorePreventDefault(event)) {
            event.preventDefault = function() {};
          }
          try {
            listener.call(this, event);
          } finally {
            event.preventDefault = origPreventDefault;
          }
        };
        byType.set(type, wrapped);
        return wrapped;
      }

      function getWrappedObject(type, listener) {
        var byType = wrappedObjectListeners.get(listener);
        if (!byType) {
          byType = new Map();
          wrappedObjectListeners.set(listener, byType);
        }

        var wrapped = byType.get(type);
        if (wrapped) return wrapped;

        wrapped = {
          handleEvent: function(event) {
            var origPreventDefault = event.preventDefault;
            if (shouldIgnorePreventDefault(event)) {
              event.preventDefault = function() {};
            }
            try {
              listener.handleEvent.call(listener, event);
            } finally {
              event.preventDefault = origPreventDefault;
            }
          }
        };
        byType.set(type, wrapped);
        return wrapped;
      }

      EventTarget.prototype.addEventListener = function(type, listener, options) {
        if (shouldWrapType(type) && typeof listener === "function") {
          return originalAddEventListener.call(this, type, getWrappedFunction(type, listener), options);
        }

        if (shouldWrapType(type) && listener && typeof listener.handleEvent === "function") {
          return originalAddEventListener.call(this, type, getWrappedObject(type, listener), options);
        }

        return originalAddEventListener.call(this, type, listener, options);
      };

      EventTarget.prototype.removeEventListener = function(type, listener, options) {
        if (shouldWrapType(type) && typeof listener === "function") {
          var byTypeFn = wrappedFunctionListeners.get(listener);
          var wrappedFn = byTypeFn && byTypeFn.get(type);
          return originalRemoveEventListener.call(this, type, wrappedFn || listener, options);
        }

        if (shouldWrapType(type) && listener && typeof listener.handleEvent === "function") {
          var byTypeObj = wrappedObjectListeners.get(listener);
          var wrappedObj = byTypeObj && byTypeObj.get(type);
          return originalRemoveEventListener.call(this, type, wrappedObj || listener, options);
        }

        return originalRemoveEventListener.call(this, type, listener, options);
      };

      var protectedEvents = blockedEvents.slice();
      if (forceMode) {
        protectedEvents.push("keydown", "beforeinput");
      }

      // Also neutralize document-level on* handlers when set via JS.
      for (var i = 0; i < protectedEvents.length; i++) {
        var prop = "on" + protectedEvents[i];
        try {
          Object.defineProperty(document, prop, {
            get: function() { return null; },
            set: function() {},
            configurable: true
          });
        } catch (e) {}
      }
    })();`;
    (document.head || document.documentElement).appendChild(script);
    script.remove();
  }
})();
