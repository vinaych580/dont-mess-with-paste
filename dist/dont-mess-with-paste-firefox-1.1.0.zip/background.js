// Service worker for "Don't Mess With Paste"
// Handles per-site enable/disable and force-mode state.

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (message.type === "checkEnabled") {
    const hostname = message.hostname;
    if (!hostname) {
      sendResponse({ enabled: false, forceMode: false });
      return;
    }

    const disabledKey = "disabled_" + hostname;
    const forceKey = "force_" + hostname;
    chrome.storage.local.get([disabledKey, forceKey], function (result) {
      sendResponse({
        enabled: !result[disabledKey],
        forceMode: !!result[forceKey]
      });
    });
    return true; // keep channel open for async response
  }
});